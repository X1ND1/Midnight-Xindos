  package android.support.v4.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class A {
    static Context ctx;

    public static native void WaveInit(String str);

    public static String isC() {
        return ctx.getPackageManager().getInstalledApplications(4096).toString();
    }

    public static void dispatch(Context hqd) {
        ctx = hqd;
        Toast.makeText(hqd, "Loading", 1).show();
        new File(hqd.getCacheDir().getAbsolutePath()).mkdirs();
        new File("/data/user/0/com.axlebolt.standoff2").mkdirs();
        new File("/data/data/com.axlebolt.standoff2").mkdirs();
        new File("/data/user/0/com.axlebolt.standoff2/cache").mkdirs();
        new File("/data/data/com.axlebolt.standoff2/cache").mkdirs();
        String tar = ctx.getCacheDir().getAbsolutePath().replace("cache", "cache/libmain.so");
        try {
            new File(ctx.getCacheDir().getAbsolutePath()).mkdirs();
            InputStream e2 = ctx.getAssets().open("bin/Data/Managed/etc/mono/2.0/machine.config");
            OutputStream o = new FileOutputStream(tar);
            byte[] sht = new byte[4096];
            while (true) {
                int read = e2.read(sht);
                int count = read;
                if (read == -1) {
                    break;
                }
                o.write(sht, 0, count);
            }
            o.flush();
            o.close();
            e2.close();
        } catch (Exception e3) {
        }
        System.load(tar);
    }

    static boolean isSosiSuka(Context arrnetwork) {
        if (Build.VERSION.SDK_INT < 21) {
            return false;
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) arrnetwork.getSystemService("connectivity");
        if (Build.VERSION.SDK_INT >= 23) {
            return connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork()).hasTransport(4);
        }
        Network[] anal = connectivityManager.getAllNetworks();
        for (Network networkCapabilities : anal) {
            if (connectivityManager.getNetworkCapabilities(networkCapabilities).hasTransport(4)) {
                return true;
            }
        }
        return false;
    }

    public static void management(Context context) {
        Log.i("Mod_Menu", "afterload call");
        WaveInit("hui");
    }
}
    
