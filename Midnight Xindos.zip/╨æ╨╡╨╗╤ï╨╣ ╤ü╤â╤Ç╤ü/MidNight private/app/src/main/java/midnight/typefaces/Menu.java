package midnight.typefaces;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import midnight.Main;

class Colors {
	public static String COLOR_GRAY_DARK = "#15161B";
	public static String COLOR_GRAY_LIGHT = "#1B1E23";
	
	public static String COLOR_BLUE_LIGHT = "#94AFDA";
	public static String COLOR_BLUE_MEDIUM = "#5BB4DE";
	public static String COLOR_BLUE_DARK = "#FFFFFFFF";
	
}

class PageButton {
	public Context context;
	public String imageSrc, pageName, pageTint;
	public ImageView icon;
	public LinearLayout line, textLine;
	public TextView name, tint;
	
	public void setChecked(boolean check) {
		if (check) {
			Menu.setDesign(line, Color.parseColor(Colors.COLOR_GRAY_LIGHT), 2f);
		} else {
			Menu.setDesign(line, Color.parseColor(Colors.COLOR_GRAY_DARK), 2f);
		}
	}
	
	public final void setAss(ImageView image, String src) {
		try {
			InputStream ims = context.getAssets().open(src);
			Drawable d = Drawable.createFromStream(ims, null);
			image.setImageDrawable(d);
		}
		catch(IOException ex) {
			// mind coder

		}
	}
	
	public PageButton(Context ctx, String _name, String _tint, String _src) {
		imageSrc = _src;
		pageName = _name;
		pageTint = _tint;
		context = ctx;
		
		// line
		line = new LinearLayout(context);
		line.setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 35)));
		line.setOrientation(LinearLayout.HORIZONTAL);
		
		setChecked(false);
		
		// ImageIcon
		icon = new ImageView(context);
		icon.setPadding(15,15,15,15);
		Menu.setFromAssets(context, icon, imageSrc);
		line.addView(icon, Menu.dp(context, 35), -1);
		
		// TextLayouts
		
		textLine = new LinearLayout(context);
		line.addView(textLine, new LinearLayout.LayoutParams(-1, -1, 1));
		textLine.setOrientation(LinearLayout.VERTICAL);
		textLine.setGravity(Gravity.CENTER_VERTICAL);
		
		name = new TextView(context);
		name.setTypeface(Menu.font(context));
		name.setTextSize(11f);
		name.setTextColor(Color.argb(255, 255, 255, 255));
		name.setText(pageName);
		name.setGravity(Gravity.BOTTOM | Gravity.LEFT);
		
		tint = new TextView(context);
		tint.setTypeface(Menu.font(context));
		tint.setTextSize(8f);
		tint.setTextColor(Color.argb(155, 255, 255, 255));
		tint.setText(pageTint);
		tint.setGravity(Gravity.TOP | Gravity.LEFT);

		textLine.addView(name, -1, Menu.dp(context, 15));
		textLine.addView(tint, -1, Menu.dp(context, 10));
	}
	
	public void setOnClick(OnClickListener clck) {
		line.setOnClickListener(clck);
	}
}

class CustomSlider {
	private Context context;
	private String buttonText;

	private int COLOR1, COLOR2, COLOR3, COLOR4;

	private LinearLayout line, textLine;
	private SeekBar slider;
	private TextView text, textValue;

	private int min, featureid;
	private int max;
	public int progress;

	private Typeface font;

	private sliderChange callback;

	public static interface sliderChange {
		void onChange(int featureid, int value);
	}

	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}

	public void setProgress(int i) {
		//callback.onChange(featureid, i);
		Main.Changes(featureid, i, "");
		progress = i;
		slider.setProgress(i);
		textValue.setText(Integer.toString(i));
	}

	public CustomSlider(Context _ctx, int featid, String _text, float size, final int mn, int mx, int pr) {
		context = _ctx;
		buttonText = _text;

		featureid = featid;

		//callback = call;

		
		min = mn;
		max = mx;
		progress = pr;

		this.COLOR1 = Color.parseColor("#F2F2F2");
		this.COLOR2 = Color.parseColor("#C7C7C7");
		this.COLOR3 = Color.parseColor("#FF464CE2");
		this.COLOR4 = Color.parseColor("#FF464CE2");

		font = Menu.font(context);
		
		line = new LinearLayout(context);
		line.setLayoutParams(new LinearLayout.LayoutParams(-1, dpi(30)));
		line.setOrientation(LinearLayout.VERTICAL);
		line.setGravity(Gravity.CENTER_VERTICAL);

		slider = new SeekBar(context);

		slider.setMax((int) mx);
		slider.setProgress(pr);
		
		GradientDrawable btn = new GradientDrawable();
		btn.setColor(Color.TRANSPARENT);

		slider.setProgressDrawable(btn);

		slider.getThumb().setColorFilter(Color.parseColor((String) "#FF464CE2"), PorterDuff.Mode.SRC_IN);

		slider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar slider2, int value, boolean a) {
					if (value < mn) {
						value = mn;
					}
					setProgress(value);
				}

				@Override
				public void onStopTrackingTouch(SeekBar slider) {

				}

				@Override
				public void onStartTrackingTouch(SeekBar slider) {

				}
			});

		text = new TextView(context);
		text.setText(buttonText);
		text.setTextSize(size);
		text.setTypeface(font);
		text.setGravity(Gravity.CENTER_VERTICAL);
		text.setTextColor(Color.WHITE);

		textValue = new TextView(context);
		textValue.setText(Integer.toString(pr));
		textValue.setTextSize(size);
		textValue.setTypeface(font);
		textValue.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
		textValue.setTextColor(Color.WHITE);

		textLine = new LinearLayout(context);
		textLine.setOrientation(LinearLayout.HORIZONTAL);
		textLine.setLayoutParams(new LinearLayout.LayoutParams(-1, -1, 1));

		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -1, 1);
		text.setLayoutParams(lp);
		textValue.setLayoutParams(lp);

		textLine.addView(text);
		textLine.addView(textValue);

		line.setPadding(10, 0, 10, 0);

		LinearLayout sliderLine = new LinearLayout(context);
		sliderLine.setPadding(10, 0, 10, 0);
		slider.setPadding(20, 0, 20, 0);

		GradientDrawable grd = new GradientDrawable();
		grd.setColor(Color.parseColor("#17191D"));
		grd.setCornerRadius(200);
		sliderLine.setBackgroundDrawable(grd);

		sliderLine.addView(slider, -1, -1);

		line.addView(textLine);
		line.addView(sliderLine, new LinearLayout.LayoutParams(-1, -1, 1));

	}

	public LinearLayout getLine() {
		return line;
	}

}

class CustomCheckBox {
	public Context context;
	public String buttonText;
	public ImageView checkbox;
	public LinearLayout line;
	public TextView name;
	
	public int feat = 0;
	
	public boolean isCheck = false;
	
	public void setChecked(boolean chck) {
		isCheck = chck;
		
		if (isCheck) {
			Menu.setFromAssets(context, checkbox, "check.png");
		} else {
			Menu.setFromAssets(context, checkbox, "uncheck.png");
		}
	}
	
	public CustomCheckBox(Context ctx, String _name, int ft) {
		context = ctx;
		buttonText = _name;
		
		line = new LinearLayout(context);
		line.setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 30)));
		line.setOrientation(LinearLayout.HORIZONTAL);
		line.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		
		feat = ft;
		
		checkbox = new ImageView(context);
		checkbox.setPadding(10,10,10,10);
		Menu.setFromAssets(context, checkbox, "uncheck.png");
		line.addView(checkbox, Menu.dp(context, 25), -1);
		
		name = new TextView(context);
		name.setTypeface(Menu.font(context));
		name.setTextSize(11f);
		name.setTextColor(Color.argb(255, 255, 255, 255));
		name.setText(buttonText);
		name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		name.setPadding(10, 0, 0, 0);
		
		line.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				setChecked(!isCheck);
				Main.Changes(feat, 0,"");
			}
		});
		
		line.addView(name, new LinearLayout.LayoutParams(-1, -1, 1));
	}
}

public class Menu {
	protected int WIDTH,HEIGHT;
	
	public static Typeface font(Context ctx) {
		return Typeface.createFromAsset(ctx.getAssets(), "Font.ttf");
	}
	
	public final void setAss(ImageView image, String src) {
		try {
			InputStream ims = context.getAssets().open(src);
			Drawable d = Drawable.createFromStream(ims, null);
			image.setImageDrawable(d);
		}
		catch(IOException ex) {
			// mind coder

		}
	}
	
	private boolean isShow = false;
	
	protected Context context;
	protected FrameLayout parentBox;
	protected LinearLayout menulayout;
	protected ScrollView scrollItems;
	
	protected ImageView iconView;
	
	protected TextView closeView;
	
	protected int isCrosshairHide;
	
	
	protected LinearLayout leftLayout, rightLayout, lineLayout;
	protected LinearLayout pageLayouts;
	
	protected ScrollView scrl;
	protected LinearLayout pageLayout;
	
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;
	public ArrayList<LinearLayout> pageList = new ArrayList<LinearLayout>();
	public ArrayList<LinearLayout> pages = new ArrayList<>();
	protected ArrayList<PageButton> pageButtons = new ArrayList<>();
	
	protected void init(Context context)
	{
		
		
		
		this.context = context;
		
		parentBox = new FrameLayout(context);

		parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			100,//initialX
			100,//initialy
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			WindowManager.LayoutParams.FLAG_FULLSCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.TOP | Gravity.LEFT;
	}
	
	public static void setFromAssets(Context context, ImageView image, String src) {
		try {
			InputStream ims = context.getAssets().open("images/" + src);
			Drawable d = Drawable.createFromStream(ims, null);
			image.setImageDrawable(d);
		}
		catch(IOException ex) {
			// MIND
		}
	}
	
	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public static int dp(Context context, float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public void showIcon() {
		ObjectAnimator animation = ObjectAnimator.ofFloat(iconView, "alpha", 0, 1.0f);
		animation.setDuration(550);
		animation.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation) {

                }

                @Override
                public void onAnimationEnd(Animator animation) {

				}

                @Override
                public void onAnimationCancel(Animator animation) {

                }

                @Override
                public void onAnimationRepeat(Animator animation) {

                }
            });
		animation.start();
		
		isShow = false;
		parentBox.removeAllViews();
		parentBox.addView(iconView, dpi(60),dpi(60));
	}
	
	public void addCH(final Crosshair ch) {
		LinearLayout line = new LinearLayout(context);

		LinearLayout linep = new LinearLayout(context);
		linep.setOrientation(LinearLayout.HORIZONTAL);
		linep.setLayoutParams(new LinearLayout.LayoutParams(-1, dpi(60)));
		GradientDrawable grad = new GradientDrawable();
		grad.setCornerRadius(15f);
		grad.setColor(Color.parseColor("#211C20"));
		linep.setBackgroundDrawable(grad);

		ImageView chs[] = {new ImageView(context), new ImageView(context), new ImageView(context), new ImageView(context), new ImageView(context)};
		String names[] = {"ch1.png", "ch2.png", "ch3.png", "ch4.png", "ch5.png"};
		for (int index = 0; index < chs.length; index++) {
			linep.addView(chs[index], new LinearLayout.LayoutParams(-2, -1, 1));
			chs[index].setPadding(15, 15, 15, 15);
			setAss(chs[index], names[index]);
			final String nms[] = names;
			final int idx = index;
			chs[index].setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Toast.makeText(context, "Прицел изменён!", Toast.LENGTH_SHORT).show();
						ch.setCross(nms[idx]);
					}
				});
		}

		line.setPadding(0, 10, 0, 10);
		line.addView(linep, -1, -1);
		pageList.get(pageList.size()-1).addView(line, -1, dpi(60));
	}
	
	public void showMenu() {
		ObjectAnimator animation = ObjectAnimator.ofFloat(menulayout, "alpha", 0, 1.0f);
		animation.setDuration(500);
		animation.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation) {

                }

                @Override
                public void onAnimationEnd(Animator animation) {

				}

                @Override
                public void onAnimationCancel(Animator animation) {

                }

                @Override
                public void onAnimationRepeat(Animator animation) {

                }
            });
		animation.start();
		isShow = true;
		parentBox.removeAllViews();
		parentBox.addView(menulayout, WIDTH, HEIGHT);
	}
	
	public static void setDesign(View view, int color, float corner) {
		GradientDrawable grad = new GradientDrawable();;
		grad.setColor(color);
		grad.setCornerRadius(corner);
		view.setBackgroundDrawable(grad);
	}
	
	public static void setDesignCorner(View view, int color, float corner1, float corner2, float corner3, float corner4) {
		GradientDrawable grad = new GradientDrawable();
		grad.setColor(color);
		grad.setCornerRadii(new float[] {corner1, corner1, corner2, corner2, corner3, corner3, corner4, corner4});
		view.setBackgroundDrawable(grad);
	}
	
	public void newCheck(int page, int f, String text) {
		CustomCheckBox check = new CustomCheckBox(context, text, f);
		pages.get(page).addView(check.line);
	}
	
	public void newSlider(int page, int f, String text, int mn, int mx) {
		CustomSlider check = new CustomSlider(context, f, text, 13, mn, mx, mn);
		pages.get(page).addView(check.getLine());
	}
	
	public void newText(int page, String text) {
		TextView pgname = new TextView(context);
		pgname.setTypeface(Menu.font(context));
		pgname.setTextSize(13f);
		pgname.setTextColor(Color.argb(255, 255, 255, 255));
		pgname.setText(text);
		pgname.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		pgname.setPadding(10, 0, 0, 10);
		pages.get(page).addView(pgname, -1, dpi(20));
	}
	
	public void newHint(int page, String text) {
		TextView pgname = new TextView(context);
		pgname.setTypeface(Menu.font(context));
		pgname.setTextSize(11f);
		pgname.setTextColor(Color.argb(155, 255, 255, 255));
		pgname.setText(text);
		pgname.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		pgname.setPadding(10, 0, 0, 10);

		pages.get(page).addView(pgname, -1, dpi(20));
	}
	
	public void showPage(int id) {
		for (int i = 0; i < pages.size(); i++) {
			pageButtons.get(i).setChecked(false);
			pages.get(i).setVisibility(View.GONE);
		}
		pageButtons.get(id).setChecked(true);
		pages.get(id).setVisibility(View.VISIBLE);
	}
	
	public void newPage(final int id, String name, String tint, String src) {
		PageButton btn = new PageButton(context, name, tint, src);
		
		btn.setOnClick(new OnClickListener() {
			public void onClick(View v) {
				showPage(id);
			}
		});
		pageButtons.add(btn);
		pageLayouts.addView(btn.line);
		
		LinearLayout page = new LinearLayout(context);
		page.setOrientation(LinearLayout.VERTICAL);
		page.setVisibility(View.GONE);
		page.setPadding(15, 5, 0, 5);
		
		TextView pgname = new TextView(context);
		pgname.setTypeface(Menu.font(context));
		pgname.setTextSize(25f);
		pgname.setTextColor(Color.argb(255, 255, 255, 255));
		pgname.setText(name);
		pgname.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		pgname.setPadding(30, 0, 0, 0);
		
		page.addView(pgname, -1, dpi(40));
		
		pages.add(page);
		pageLayout.addView(page, -1, -1);
	}
	
	public Menu(Context context) {
		init(context);

		WIDTH = dpi(430);
		HEIGHT = dpi(300);
		
		menulayout = new LinearLayout(context);
		menulayout.setOrientation(LinearLayout.HORIZONTAL);
		setDesign(menulayout, Color.parseColor(Colors.COLOR_GRAY_DARK), 2f);
		
		iconView = new ImageView(context);
		setFromAssets(context, iconView, "icon.png");
		
		// Layouts
		
		lineLayout = new LinearLayout(context);
		GradientDrawable grad = new GradientDrawable(
			GradientDrawable.Orientation.BOTTOM_TOP,
			new int[] {
				Color.parseColor(Colors.COLOR_BLUE_LIGHT),
				Color.parseColor(Colors.COLOR_BLUE_DARK),
			}
		);
		grad.setCornerRadius(2f);
		lineLayout.setBackgroundDrawable(grad);
		menulayout.addView(lineLayout, dpi(3), -1);
		
		leftLayout = new LinearLayout(context);
		leftLayout.setOrientation(LinearLayout.VERTICAL);
		leftLayout.setGravity(Gravity.CENTER);
		
		rightLayout = new LinearLayout(context);
		setDesignCorner(rightLayout, Color.parseColor(Colors.COLOR_GRAY_LIGHT), 0f, 2f, 2f, 0f);
		
		menulayout.addView(leftLayout, dpi(150), -1);
		menulayout.addView(rightLayout, new LinearLayout.LayoutParams(-1, -1, 1));
		
		// Page buttons layout
		
		pageLayouts = new LinearLayout(context);
		pageLayouts.setOrientation(LinearLayout.VERTICAL);
		pageLayouts.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.TOP);
		pageLayouts.setPadding(0, 5, 0, 5);
		
		// page
		scrl = new ScrollView(context);
		pageLayout = new LinearLayout(context);
		pageLayout.setGravity(Gravity.CENTER);
		pageLayout.setOrientation(LinearLayout.VERTICAL);
		
		rightLayout.addView(scrl, -1, -1);
		scrl.addView(pageLayout, -1, -1);
		
		closeView = new TextView(context);
		closeView.setTypeface(Menu.font(context));
		closeView.setTextSize(15f);
		closeView.setTextColor(Color.argb(255, 255, 255, 255));
		closeView.setText("Close Menu");
		closeView.setGravity(Gravity.BOTTOM | Gravity.LEFT);
		closeView.setPadding(15, 0, 0, 15);
		
		leftLayout.addView(pageLayouts, new LinearLayout.LayoutParams(-1, -1, 1));
		
		closeView.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				showIcon();
			}
		});
		
		leftLayout.addView(closeView, new LinearLayout.LayoutParams(-1, dpi(30)));
		
		wmManager.addView(parentBox, wmParams);
		showMenu();
        
        //showIcon();
	}



	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
					if (!isShow && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}
					break;
			}
			return true;
		}
	};
}
