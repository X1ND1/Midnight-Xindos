package midnight;

import android.animation.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.util.*;
import android.os.*;
import android.view.*;
import android.text.*;
import android.widget.*;
import midnight.typefaces.*;
import midnight.typefaces.Menu;
import android.app.AlertDialog;
import android.R;
import android.net.Uri;
import javax.security.auth.Destroyable;
import java.util.regex.MatchResult;
import android.transition.AutoTransition;
import java.io.UnsupportedEncodingException;
import midnight.typefaces.Watermarking;
import midnight.typefaces.Crosshair;
import midnight.typefaces.AlertInput;

//private String assetSavePath = "";
public class Main 
{
	protected static Context context;
	protected LinearLayout childOfScroll;
	
	public static native void Changes(int feature, int value, String strv);

    private static native String[] getFeatures();
	
	public static void start(final Context context) {
		System.loadLibrary("midnight");
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				new Main().MenuMain(context);
			}
		}, 3000);
	}
	
	public int num(String n) {
		return Integer.parseInt(n);
	}
	
	
	
	
	
	public final void MenuMain(final Context context) {
		Main.context = context;
		
		Menu menu=new Menu(context);
		
		try {
		
		String[] listFT = getFeatures();
		int pageid = 0;
		
			for (int i = 0; i < listFT.length; i++) {
				String lex = listFT[i];
				final String[] split = lex.split("_");
				String type = split[0];

				if (type.equals("page")) {
					menu.newPage(pageid, split[1], split[2], split[3]);
					pageid++;
				} else if (type.equals("switch")) {
					menu.newCheck(num(split[1]), num(split[2]), split[3]);
				} else if (type.equals("title")) {
					menu.newText(num(split[1]), split[2]);
				} else if (type.equals("hint")) {
					menu.newHint(num(split[1]), split[2]);
				} else if (type.equals("slider")) {
					menu.newSlider(num(split[1]), num(split[2]), split[3], num(split[4]), num(split[5]));;
					} else if (type.equals("input")) {
						CustomButton butt = new CustomButton(context, 0, split[3], 13f, new CustomButton.buttonClick() {
							public void onClick(int f) {
						AlertInput al = new AlertInput(context, "Enter text", new AlertInput.onChange() {
							public void onPut(String t) {
								Changes(num(split[2]), 0, t);
							}
						});
						}
						});
						menu.pages.get(num(split[1])).addView(butt.getLine());
					}
			/*
			final Watermarking Watermarking = new Watermarking(context);
            Watermarking.setWidth(Watermarking.dpi(300));
            Watermarking.setHeight(Watermarking.dpi(30));
            Watermarking.isVisible(true);
			
				final Crosshair crosshair = new Crosshair(context);
				crosshair.setWidth(crosshair.dpi(30));
				crosshair.setHeight(crosshair.dpi(30));
				crosshair.isVisible(false);
			*/
		}
		
			menu.newText(0,"Cheat Make By Executive");
			menu.showPage(0);
			
		} catch (Exception e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
	}
}

