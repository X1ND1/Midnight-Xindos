#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Chams.h>
#include "Unity/Vector3.h"
#include "Unity/Quaternion.h"
#include "Includes/Obfuscate.h"


extern "C" {
	
	
	
	struct My_Patches {MemoryPatch Buy, Defuse, Plant, Radar, Money, Infinityammo, Godmode, Norecoil, Resphack, FireRate, Nospread, Rankfrature, Idfeature, SpeedHack, Fly, Dont, AntiFlash;} hexPatches;
	
	
bool norecoil, frags, smokeg,  shoot, infinity, chats, nick, nickanim, idanim, id, clan, clannim = false;
	
bool enplayer = false;
bool m91, m92, m93, m94, m95, m96, m97 = false;
	bool kar1, kar2, kar3, kar4, kar5, kar6, kar7, kar8, kar9 = false;
	bool jk1, jk2, jk3, jk4, jk5, jk6 = false;
	bool but1, but2, but3, but4, but5, but6, but7 = false;
	bool flip1, flip2, flip3, flip4, flip5, flip6, flip7 = false;
	bool kun1, kun2, kun3, kun4, kun5, kun6, kun7, kun8 = false;
	bool scor1, scor2, scor3, scor4, scor5, scor6 = false;
	bool tanto1, tanto2, tanto3, tanto4, tanto5, tanto6, tanto7, tanto8 = false;
	bool glov1, glov2, glov3, glov4, glov5, glov6, glov7, glov8, glov9, glov10, glov11 = false;
	bool g22, usp, p350, tec9, fs, deagle, ump, mp7, p90, mp5, m40, famas, fnfal, akr, m4, akr12, m16, m4a1, awm, sm1014, fabm, m60, m9, kar, jk, butterfly, flip, kunai, scorpion, tanto, bomb, m110, knife, ghe, gsmoke, gflash = false;
int skinid = false;
bool friendly, DontR, fastplant, GImunnity = false;

bool chams, wireframe, outline, glow = false;
int rc, gc, bc = 1;
int orr2, ogg2, obb2 = 1;
int gr, gg, gb = 1;
int wwidth, owidth = 1;

int scaleX, scaleY, scaleZ;
float X1, Y1, Z1;
float fly;
float speed;
void *myPlayer = NULL;

	
	

float corrvalue = 0.1f;
    int he = 91;
	int Lol = 0;
    float handsxq;
    float handsyq;
    float handszq;
    int SpawnValue = 1;
    int CullFaceValue;
    float speedSpin = 1;
    float spinY = 0.0f;

using namespace std;
std::string utf16le_to_utf8(const std::u16string &u16str) {
    if (u16str.empty()) { return std::string(); }
    const char16_t *p = u16str.data();
    std::u16string::size_type len = u16str.length();
    if (p[0] == 0xFEFF) {
        p += 1;
        len -= 1;
    }

    std::string u8str;
    u8str.reserve(len * 3);

    char16_t u16char;
    for (std::u16string::size_type i = 0; i < len; ++i) {

        u16char = p[i];

        if (u16char < 0x0080) {
            u8str.push_back((char) (u16char & 0x00FF));
            continue;
        }
        if (u16char >= 0x0080 && u16char <= 0x07FF) {
            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));
            continue;
        }
        if (u16char >= 0xD800 && u16char <= 0xDBFF) {
            uint32_t highSur = u16char;
            uint32_t lowSur = p[++i];
            uint32_t codePoint = highSur - 0xD800;
            codePoint <<= 10;
            codePoint |= lowSur - 0xDC00;
            codePoint += 0x10000;
            u8str.push_back((char) ((codePoint >> 18) | 0xF0));
            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));
            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));
            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));
            continue;
        }
        {
            u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));
            u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));
            continue;
        }
    }

    return u8str;
}

typedef struct _monoString {
    void *klass;
    void *monitor;
    int length;

    const char *toChars(){
        u16string ss((char16_t *) getChars(), 0, getLength());
        string str = utf16le_to_utf8(ss);
        return str.c_str();
    }

    char chars[0];

    char *getChars() {
        return chars;
    }

    int getLength() {
        return length;
    }
    std::string get_string() {
        
        return std::string(toChars());
    }
} monoString;

monoString *CreateMonoString(const char *str) {
    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress("libil2cpp.so", 0x15E8654); 

    return String_CreateString(NULL, str);
}




const char *libName = "libil2cpp.so";


JNIEXPORT jobjectArray JNICALL Java_midnight_Main_getFeatures( JNIEnv *env,jobject activityObject) {jobjectArray ret;
	const char *features[] = {
		"page_Cheat Menu_Cheats_Cheats.png", // 0
		"page_Visual Menu_Visuals_Visuals.png", // 0
		"page_Skin Menu_Weapon Menu_Aimbot.png", // 0
		"page_Author_Cheat Author_Player.png", // 0
		
		"title_0_Functions",
		"switch_0_1_No Recoil",
		"switch_0_2_Infinity Ammo",
		"switch_0_3_Fire Rate",
		"switch_0_4_Money Hack",
		"switch_0_5_Defuse Anywhere",
		"switch_0_8_Spam Message",
		"title_0_Player",
		"switch_0_9_Enemy Scale",
		"slider_0_10_Scale X_0_250_0",
	    "slider_0_11_Scale Y_0_250_0",
	    "slider_0_12_Scale Z_0_250_0",
		"title_0_Player Controller",
		"switch_0_6_Custom Nick",
		"input_0_18_Input Nick:",
		"switch_0_13_Custom ID",
	    "input_0_19_Input ID:",
		"switch_0_13_Custom Clan Tag",
	    "input_0_19_Input Clan Tag:",
		"switch_0_13_Custom Game Version",
	    "input_0_19_Input Game Version:",
		"title_0_Admin",
		"switch_0_113377_Shot Flash Grenades",
		"switch_0_113378_Shot Smoke Grenades",
		"switch_0_113379_Shot Frag Grenades",
		
		"title_1_Visuals",
		"switch_1_18_Chams",
		"switch_1_19_Wireframe",
		"switch_1_20_Outline",
		"switch_1_26_Glow",
		"slider_1_14_Color R_0_255_0",
		"slider_1_15_Color G_0_255_0",
		"slider_1_16_Color B_0_265_0",
		"hind_2_Esp",
		"switch_2_444_Esp Line",
		"switch_2_445_Esp Box",
		
		"title_2_SkinChanger",
		"switch_2_17_AKR",
		"switch_2_17_Awm",
		"switch_2_17_Deagle",
		"hint_2_Knifes",
		"switch_2_17_Karambit",
		"switch_2_17_Butterfly",
		"switch_2_17_Tecmix",
		"switch_2_17_Huntsman",
		"hint_2_Gloves",
		"switch_2_17_Disco",
		"switch_2_17_Joker",
		"switch_2_17_Hazard",
		"switch_2_17_Nexus",
		"switch_2_17_Nuclear",
		"switch_2_17_Tiger",
		"switch_2_17_Quadratic",
		"switch_2_17_Scarecrow",
		"switch_2_17_Hornet",
		"switch_2_17_Disco V2",
		"switch_2_17_Waves",
		"switch_2_17_Goth",
		"switch_2_17_Hitman",
		"switch_2_17_Volcanic",
		"switch_2_17_Cosmos",
		
	
		
		"title_3_Credit",
		"text_3_Telegram",
		"hint_3_Channel - t.me/ExecutiveOFC",
		"hint_3_Questions? pm - t.me/ManagementEbat",
	};
	
	int Total_Feature = (sizeof features / sizeof features[0]);
	ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"), env->NewStringUTF(""));
	
	for (int i = 0; i < Total_Feature; i++) env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
	return (ret);
} 

void hexChange(bool &var, MemoryPatch &patch) {
	var = !var;
	if (var) {
		patch.Modify();
	} else {
		patch.Restore();
	}
}

void updateChams() {
	SetWallhack(chams);
	SetWireframe(wireframe);
	SetGlow(glow);
	SetOutline(outline);
	SetOR(orr2);SetOG(ogg2);SetOB(obb2);
	SetGR(gr);SetGG(gg);SetGB(gb);
	SetR(rc);SetG(gc);SetB(bc);SetWireframeWidth(wwidth);SetOutlineWidth(owidth);
}

JNIEXPORT void JNICALL Java_midnight_Main_Changes( JNIEnv *env,jobject activityObject, jint feature, jint value) {jobjectArray ret;
	switch (feature) {
		
		case 18:
			chams = !chams;
			updateChams();
			break;
		case 22:
			wireframe = !wireframe;
			updateChams();
			break;
		case 24:
			outline = !outline;
			updateChams();
			break;
		case 26:
			glow = !glow;
			updateChams();
			break;
		
		case 9:
            enplayer = !enplayer;
            break;
			
		case 1:
			norecoil = !norecoil;
			break;
			
		case 8:
			chats = !chats;
			break;
			
	    case 6:
			nick = !nick;
			break;
			
			case 7:
				nickanim = !nickanim;
				break;
				
			case 113377:
				shoot = !shoot;
				break;
				
				case 113378:
				smokeg = !smokeg;
				break;
				
				case 113379:
				frags = !frags;
				break;
	    
			
			
		     
		
	}
	updateChams();
}
// Extern end
}

// ---------- Hooking ---------- //


void (*old_setskins)(void *instance, int hui1, int hui2);
void setskins(void *instance, int hui1, int hui2) {
    if (instance != NULL) {
        if (setskins){
            hui2 = skinid;
        }
        if (m91){
            hui2 = 71001;
        }
        if (m92){
            hui2 = 71002;
        }
        if (m93){
            hui2 = 71003;
        }
        if (m94){
            hui2 = 71004;
        }
        if (m95){
            hui2 = 71005;
        }
        if (m96){
            hui2 = 97100;
        }
        if (m97){
            hui2 = 157100;
        }
        if (kar1){
            hui2 = 72002;
        }
        if (kar2){
            hui2 = 72003;
        }
        if (kar3){
            hui2 = 72004;
        }
        if (kar4){
            hui2 = 72005;
        }
        if (kar5){
            hui2 = 72006;
        }
        if (kar6){
            hui2 = 72007;
        }
        if (kar7){
            hui2 = 97201;
        }
        if (kar8){
            hui2 = 97203;
        }
        if (kar9){
            hui2 = 157200;
        }
        if (jk1){
            hui2 = 73002;
        }
        if (jk2){
            hui2 = 73003;
        }
        if (jk3){
            hui2 = 73004;
        }
        if (jk4){
            hui2 = 73006;
        }
        if (jk5){
            hui2 = 97300;
        }
        if (jk6){
            hui2 = 157300;
        }
        if (but1){
            hui2 = 47503;
        }
        if (but2){
            hui2 = 47502;
        }
        if (but3){
            hui2 = 57501;
        }
        if (but4){
            hui2 = 47504;
        }
        if (but5){
            hui2 = 47505;
        }
        if (but6){
            hui2 = 97500;
        }
        if (but7){
            hui2 = 157500;
        }
        if (flip1){
            hui2 = 67701;
        }
        if (flip2){
            hui2 = 67702;
        }
        if (flip3){
            hui2 = 67703;
        }
        if (flip4){
            hui2 = 67704;
        }
        if (flip5){
            hui2 = 67705;
        }
        if (flip6){
            hui2 = 97700;
        }
        if (flip7){
            hui2 = 157700;
        }
        if (kun1){
            hui2 = 77813;
        }
        if (kun2){
            hui2 = 77814;
        }
        if (kun3){
            hui2 = 77815;
        }
        if (kun4){
            hui2 = 77816;
        }
        if (kun5){
            hui2 = 77817;
        }
        if (kun6){
            hui2 = 97800;
        }
        if (kun7){
            hui2 = 97801;
        }
        if (kun8){
            hui2 = 157800;
        }
        if (scor1){
            hui2 = 87919;
        }
        if (scor2){
            hui2 = 87920;
        }
        if (scor3){
            hui2 = 87921;
        }
        if (scor4){
            hui2 = 87922;
        }
        if (scor5){
            hui2 = 97900;
        }
        if (scor6){
            hui2 = 157900;
        }
        if (tanto1){
            hui2 = 138000;
        }
        if (tanto2){
            hui2 = 138001;
        }
        if (tanto3){
            hui2 = 138002;
        }
        if (tanto4){
            hui2 = 138003;
        }
        if (tanto5){
            hui2 = 138004;
        }
        if (tanto6){
            hui2 = 138005;
        }
        if (tanto7){
            hui2 = 148000;
        }
        if (tanto8){
            hui2 = 158000;
        }
    }

    old_setskins(instance, hui1, hui2);
}

void (*SetPlayerWeapon)(void* _this, int);
void(*old_gameupdate)(void *instance);
void gameupdate(void *instance) {
    if (instance != NULL) {
        if (g22) {
            SetPlayerWeapon(instance, 11);
            g22 = false;
        }
        if (usp) {
            SetPlayerWeapon(instance, 12);
            usp = false;
        }
        if (p350) {
            SetPlayerWeapon(instance, 13);
            p350 = false;
        }
        if (tec9) {
            SetPlayerWeapon(instance, 16);
            tec9 = false;
        }
        if (fs) {
            SetPlayerWeapon(instance, 17);
            fs = false;
        }
        if (deagle) {
            SetPlayerWeapon(instance, 15);
            deagle = false;
        }
        if (ump) {
            SetPlayerWeapon(instance, 32);
            ump = false;
        }
        if (mp7) {
            SetPlayerWeapon(instance, 34);
            mp7 = false;
        }
        if (p90) {
            SetPlayerWeapon(instance, 35);
            p90 = false;
        }
        if (mp5) {
            SetPlayerWeapon(instance, 36);
            mp5 = false;
        }
        if (sm1014) {
            SetPlayerWeapon(instance, 62);
            sm1014 = false;
        }
        if (fabm) {
            SetPlayerWeapon(instance, 63);
            fabm = false;
        }
        if (m60) {
            SetPlayerWeapon(instance, 64);
            m60 = false;
        }
        if (m40) {
            SetPlayerWeapon(instance, 52);
            m40 = false;
        }
        if (famas) {
            SetPlayerWeapon(instance, 48);
            famas = false;
        }
        if (fnfal) {
            SetPlayerWeapon(instance, 49);
            fnfal = false;
        }
        if (akr) {
            SetPlayerWeapon(instance, 44);
            akr = false;
        }
        if (m4) {
            SetPlayerWeapon(instance, 44);
            m4 = false;
        }
        if (akr12) {
            SetPlayerWeapon(instance, 46);
            akr12 = false;
        }
        if (m16) {
            SetPlayerWeapon(instance, 47);
            m16 = false;
        }
        if (m4a1) {
            SetPlayerWeapon(instance, 43);
            m4a1 = false;
        }
        if (awm) {
            SetPlayerWeapon(instance, 51);
            awm = false;
        }
        if (m9) {
            SetPlayerWeapon(instance, 71);
            m9 = false;
        }
        if (kar) {
            SetPlayerWeapon(instance, 72);
            kar = false;
        }
        if (jk) {
            SetPlayerWeapon(instance, 73);
            jk = false;
        }
        if (butterfly) {
            SetPlayerWeapon(instance, 75);
            butterfly = false;
        }
        if (flip) {
            SetPlayerWeapon(instance, 77);
            flip = false;
        }
        if (kunai) {
            SetPlayerWeapon(instance, 78);
            kunai = false;
        }
        if (scorpion) {
            SetPlayerWeapon(instance, 79);
            scorpion = false;
        }
        if (tanto) {
            SetPlayerWeapon(instance, 80);
            tanto = false;
        }
        if (bomb) {
            SetPlayerWeapon(instance, 100);
            bomb = false;
        }
        if (knife) {
            SetPlayerWeapon(instance, 70);
            knife = false;
        }
        if (m110) {
            SetPlayerWeapon(instance, 53);
            m110 = false;
        }
        if (ghe) {
            SetPlayerWeapon(instance, 91);
            ghe = false;
        }
        if (gsmoke) {
            SetPlayerWeapon(instance, 92);
            gsmoke = false;
        }
        if (gflash) {
            SetPlayerWeapon(instance, 93);
            gflash = false;
        }
        if (friendly) {
            *(bool *)((uint64_t) instance + 0x30) = true;
        }
        old_gameupdate(instance);
    }
    old_gameupdate(instance);
}


int(*old_glov)(void *instance);
int glov(void *instance) {
    if (glov1) {
        return 3000;
    }
    if (glov2) {
        return 3001;
    }
    if (glov3) {
        return 3002;
    }
    if (glov4) {
        return 3003;
    }
    if (glov5) {
        return 3004;
    }
    if (glov6) {
        return 3005;
    }
    if (glov7) {
        return 3006;
    }
    if (glov8) {
        return 3007;
    }
    if (glov9) {
        return 3008;
    }
    if (glov10) {
        return 3009;
    }
    if (glov11) {
        return 3010;
    }
    return old_glov(instance);
}


monoString* (*old_uid)(void* player, void* photon);
monoString* uid(void* player, void* photon) {
    if (player != NULL) {
        if (nick) {
   return CreateMonoString("<color=#00FFD5>t.me/ExecutiveOFC</color>");
  }
 }
    old_uid(player, photon);
} 

monoString* (*old_uidanim)(void* player, void* photon);
monoString* uidanim(void* player, void* photon) {
    if (player != NULL) {
        if (nickanim) {
   return CreateMonoString("<color=#00FFD5>t.me/ExecutiveOFC</color>");
  }
 }
    old_uidanim(player, photon);
} 

void (*old_SendToTeam)(void* player, monoString* chat, monoString* msg);
void SendToTeam(void* player, monoString* chat, monoString* msg) {
    if (player != NULL) {
        if (chats) {
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
            old_SendToTeam(player, chat, msg);
        }
    }
    old_SendToTeam(player, chat, msg);
}

bool (*old_No)(void *instance);
bool No(void *instance) {
    if (norecoil) {
        return true;
    }
    return old_No(instance);
}

void *get_transform(void *player)
{
    if (!enplayer)
        return NULL;
    static const auto get_transform_injected = reinterpret_cast<uint64_t(__fastcall *)(
    void *)>(getAbsoluteAddress(libName, 0x1A44658));
    return (void *) get_transform_injected(player);
}
void (*set_localScale)(void *transform, Vector3 scale);
bool (*get_shooting)(void* me);
void (*SpawnGrenade)(void* me, int id);
void (*PlayerUpdate)(void *player);
void _PlayerUpdate(void *player)
{
    if (enplayer)
    {
        set_localScale(get_transform(player), Vector3(scaleX, scaleY, scaleZ));
    }
    if (shoot && player && get_shooting(player)) {
    	SpawnGrenade(player, 7);
    }
PlayerUpdate(player);
}

static int str_to_int(const char* valueof) {
    return atoi(valueof);
}

bool rps(std::string& str, const std::string& from, const std::string& to) {
    size_t start_pos = str.find(from);
    if (start_pos == std::string::npos)
        return false;
    str.replace(start_pos, from.length(), to);
    return true;
}

std::string ReplaceString(std::string subject, const std::string& search, const std::string& replace) {
    size_t pos = 0;
    while ((pos = subject.find(search, pos)) != std::string::npos) {
        subject.replace(pos, search.length(), replace);
        pos += replace.length();
    }
    return subject;
}

bool isn(const std::string& str) {
    for (char const& c : str) {
        if (std::isdigit(c) == 0) return false;
    }
    return true;
}

int length;


//antiban device

std::string gen_random(const int len) {
    string id;
    static const char gsfid[] =
        "0123456789"
        "abcdefghijklmnopqrstuvwxyz";
    srand((unsigned)time(NULL) * getpid());
    id.reserve(len);
    for (int i = 0; i < len; ++i)
        id += gsfid[rand() % (sizeof(gsfid) - 1)];
    return id;
}

bool contains(std::string in, std::string target) {
    if(strstr(in.c_str(), target.c_str())) {
        return true;
    }
    return false;
}


//antidetect

monoString* (*old_services)(...);
monoString* services(void* inst, void* inst2, void* inst3) {
    std::string valtostd(old_services(inst, inst2, inst3)->toChars());
    if (contains(valtostd, OBFUSCATE("MessageForwardingService"))) {
        return CreateMonoString(OBFUSCATE("com.google.firebase.messaging.MessageForwardingService|com.applovin.impl.sdk.utils.AppKilledService|com.applovin.impl.adview.activity.FullscreenAdService|com.google.android.gms.measurement.AppMeasurementService|com.google.android.gms.measurement.AppMeasurementJobService|com.google.firebase.components.ComponentDiscoveryService|com.google.android.gms.auth.api.signin.RevocationBoundService|com.google.firebase.messaging.FirebaseMessagingService|com.google.firebase.messaging.cpp.ListenerService|com.google.firebase.messaging.cpp.RegistrationIntentService|com.axlebolt.bolt.android.notifications.BoltFirebaseMessagingService|com.google.android.datatransport.runtime.backends.TransportBackendDiscovery|com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService"));
    }
    else if (contains(valtostd, OBFUSCATE("MessagingUnityPlayerActivity"))) {
        return CreateMonoString(OBFUSCATE("com.google.firebase.MessagingUnityPlayerActivity|com.facebook.unity.FBUnityLoginActivity|com.facebook.unity.FBUnityDialogsActivity|com.facebook.unity.FBUnityAppLinkActivity|com.facebook.unity.FBUnityDeepLinkingActivity|com.facebook.unity.FBUnityGameRequestActivity|com.facebook.unity.FBUnityCreateGameGroupActivity|com.facebook.unity.FBUnityJoinGameGroupActivity|com.facebook.unity.AppInviteDialogActivity|com.adcolony.sdk.AdColonyInterstitialActivity|com.adcolony.sdk.AdColonyAdViewActivity|com.facebook.FacebookActivity|com.facebook.CustomTabMainActivity|com.facebook.CustomTabActivity|com.applovin.adview.AppLovinInterstitialActivity|com.applovin.adview.AppLovinFullscreenActivity|com.applovin.sdk.AppLovinWebViewActivity|com.applovin.mediation.MaxDebuggerActivity|com.applovin.mediation.MaxDebuggerDetailActivity|com.applovin.mediation.MaxDebuggerMultiAdActivity|com.applovin.mediation.MaxDebuggerAdUnitsListActivity|com.applovin.mediation.MaxDebuggerAdUnitDetailActivity|com.applovin.mediation.MaxDebuggerTestLiveNetwo"));
    }
    else {
        return old_services(inst, inst2, inst3);
    }
}

typedef std::string yikes;


monoString* (*safevalue)(...);
monoString* safevalue2(void* inst) {
    monoString* b = safevalue(inst);
    yikes valtostd(b->toChars());
    monoString* returned = b;
    if (contains(valtostd, OBFUSCATE("|main.")) && contains(valtostd, OBFUSCATE("base.apk:")) && contains(valtostd, OBFUSCATE(".com.axlebolt.standoff2.obb:"))) {
        returned = CreateMonoString(OBFUSCATE("base.apk:8521a43c88e5c31cf5749c99b9eb58ad:86634153|main.1090.com.axlebolt.standoff2.obb:5d37ee1210e3dbedf6130f342f2a0268:1397192921"));
    }
    if (contains(valtostd, OBFUSCATE("base.apk:")) && !contains(valtostd, OBFUSCATE("/data")) && !contains(valtostd, OBFUSCATE("|")) && !contains(valtostd, OBFUSCATE(".com.axlebolt.standoff2.obb:"))) {
        returned = CreateMonoString(OBFUSCATE("base.apk:8521a43c88e5c31cf5749c99b9eb58ad:86634153"));
    }
    if (contains(valtostd, OBFUSCATE("=")) && !contains(valtostd, OBFUSCATE("data")) && !contains(valtostd, OBFUSCATE(" ")) && !contains(valtostd, OBFUSCATE("|"))) {
        returned = CreateMonoString(OBFUSCATE("lcG7acvUIg0k4FQSQmAbyw1tN0o="));
        returned = CreateMonoString(OBFUSCATE("IxFw3vzieydudo4="));
    }
    if (contains(valtostd, OBFUSCATE("3")) && !contains(valtostd, OBFUSCATE("|")) && !contains(valtostd, OBFUSCATE(" ")) && valtostd.length() == 16) {
        returned = CreateMonoString(gen_random(16).c_str());
    }
    if (contains(valtostd, OBFUSCATE("/data/")) && contains(valtostd, OBFUSCATE(".so")) && contains(valtostd, OBFUSCATE("|"))) {
        yikes lib1 = OBFUSCATE("/data/data/com.axlebolt.standoff2/cache/libmain.so");
        yikes lib2 = OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache/libmain.so");
        yikes lib4 = OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache/libunity.so");
        yikes lib5 = OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache/libfmod.so");
        yikes lib6 = OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache/libfmodstudio.so");
        if (contains(valtostd, lib1)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib1 + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
        if (contains(valtostd, lib2)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib2 + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
        if (contains(valtostd, lib4)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib4 + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
        if (contains(valtostd, lib5)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib5 + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
        if (contains(valtostd, lib6)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib6 + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
        if (contains(valtostd, OBFUSCATE("/storage/")) && contains(valtostd, OBFUSCATE(".so")) && contains(valtostd, OBFUSCATE("|"))) {
        yikes lib3 = OBFUSCATE("/storage/emulated/0/Android/data/com.axlebolt.standoff2/files/il2cpp/Metadata/libil2cpp.so|");
        if (contains(valtostd, lib3)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (lib3 + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
        
        if (contains(valtostd, OBFUSCATE("/storage/")) && contains(valtostd, OBFUSCATE(".dat")) && contains(valtostd, OBFUSCATE("|"))) {
        yikes dat = OBFUSCATE("/storage/emulated/0/Android/data/com.axlebolt.standoff2/files/il2cpp/Resources/mscorlib.dll-resources.dat|");
        yikes dat2 = OBFUSCATE("/storage/emulated/0/Android/data/com.axlebolt.standoff2/files/il2cpp/Metadata/global-metadata.dat|");

if (contains(valtostd, dat)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (dat + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
        if (contains(valtostd, dat2)) {
            yikes basicString;
            basicString += ReplaceString(valtostd, (dat2 + "|"), "");
            returned = CreateMonoString(basicString.c_str());
        }
    }
    return returned;
}
}
}

monoString* (*old_assetspath)(...);
monoString* assetspath(void* inst) {
    std::string valtostd(old_assetspath(inst)->toChars());
    if (contains(valtostd, OBFUSCATE("/data/data/com.axlebolt.standoff2/cache/"))) {
        return CreateMonoString(OBFUSCATE("/data/data/com.axlebolt.standoff2/cache/libmain.so"));
    }
    else if (contains(valtostd, OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache"))) {
        return CreateMonoString(OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache/libmain.so"));
        return old_assetspath(inst);
    }
    else {
        return old_assetspath(inst);
    }
}

//antidetect

monoString* (*old_apkpath)(...);
monoString* apkpath(void* inst) {
    std::string valtostd(old_apkpath(inst)->toChars());
    if (contains(valtostd, OBFUSCATE("/data/data/com.axlebolt.standoff2/cache/"))) {
        return CreateMonoString(OBFUSCATE("/data/data/com.axlebolt.standoff2/cache/base.apk"));
    }
    else if (contains(valtostd, OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache"))) {
        return CreateMonoString(OBFUSCATE("/data/user/0/com.axlebolt.standoff2/cache/base.apk"));
        return old_apkpath(inst);
    }
    else {
        return old_apkpath(inst);
    }
}


         monoString* (*old_libpath)(...);
        monoString* libpath(void* inst) {
            std::string valtostd(old_libpath(inst)->toChars());
            if (contains(valtostd, OBFUSCATE("libadcolony.so"))) {
                return CreateMonoString(OBFUSCATE("libadcolony.so:4d8dea4e416b0408a085b17c9fb3dfdb"));
            } else if (contains(valtostd, OBFUSCATE("libFirebaseCppAnalytics.so"))) {
                return CreateMonoString(OBFUSCATE("libFirebaseCppAnalytics.so:7f6932160fe2f16d970beabb74b35f43"));
            } else if (contains(valtostd, OBFUSCATE("libFirebaseCppApp-6_16_1.so"))) {
                return CreateMonoString(OBFUSCATE("libFirebaseCppApp-6_16_1.so:3e2c2f09dc30dd60f83598e982fdd183"));
            } else if (contains(valtostd, OBFUSCATE("libFirebaseCppMessaging.so"))) {
                return CreateMonoString(OBFUSCATE("libFirebaseCppMessaging.so:645f50fbc3b2b82c1c228a03050b8ccd"));
            } else if (contains(valtostd, OBFUSCATE("libFirebaseCppRemoteConfig.so"))) {
                return CreateMonoString(OBFUSCATE("libFirebaseCppRemoteConfig.so:190fc4c378ed04863f85bbdf7dab08cf"));
            } else if (contains(valtostd, OBFUSCATE("libfmod.so"))) {
                return CreateMonoString(OBFUSCATE("libfmod.so:c5780306b7dc557c6ae8b262da96618f"));
            } else if (contains(valtostd, OBFUSCATE("libfmodL.so"))) {
                return CreateMonoString(OBFUSCATE("libfmodL.so:d867134426a8a1629ead34d0e7b14703"));
            } else if (contains(valtostd, OBFUSCATE("libfmodstudio.so"))) {
                return CreateMonoString(OBFUSCATE("libfmodstudio.so:4af6b9d541ab53bba6f3aa98c9107c5d"));
            } else if (contains(valtostd, OBFUSCATE("libfmodstudioL.so"))) {
                return CreateMonoString(OBFUSCATE("libfmodstudioL.so:b1cb4a8d8b27b745e510bfae1d8b27d0"));
            } else if (contains(valtostd, OBFUSCATE("libgvraudio.so"))) {
                return CreateMonoString(OBFUSCATE("libgvraudio.so:4f2d76de384bc30b007ef535d22414fc"));
            } else if (contains(valtostd, OBFUSCATE("libil2cpp.so"))) {
                return CreateMonoString(OBFUSCATE("libil2cpp.so:ab5673d80cefad07847374fd49e2dd52"));
            } else if (contains(valtostd, OBFUSCATE("libjs.so"))) {
                return CreateMonoString(OBFUSCATE("libjs.so:9f13f09a0c540b2530cc09f0bbd4e362"));
            } else if (contains(valtostd, OBFUSCATE("libmain.so"))) {
                return CreateMonoString(OBFUSCATE("libmain.so:ca3f40b27b48aad82d66a7f42b401ecd"));
            } else if (contains(valtostd, OBFUSCATE("libnative-googlesignin.so"))) {
                return CreateMonoString(OBFUSCATE("libnative-googlesignin.so:ec507a1dde75dccf22c58c4e63840601"));
            } else if (contains(valtostd, OBFUSCATE("libresonanceaudio.so"))) {
                return CreateMonoString(OBFUSCATE("libresonanceaudio.so:ef511f1bdcdc48a01d312a568a761aab"));
            } else if (contains(valtostd, OBFUSCATE("libsigner.so"))) {
                return CreateMonoString(OBFUSCATE("libsigner.so:76f0e40e56d8c4c628948222039ba3da"));
            } else if (contains(valtostd, OBFUSCATE("libunity.so"))) {
                return CreateMonoString(OBFUSCATE("libunity.so:d971b529cd4461373215769fee1e947f"));
            } else if (contains(valtostd, OBFUSCATE("libvivox-sdk.so"))) {
                return CreateMonoString(OBFUSCATE("libvivox-sdk.so:23612edf58efcdd9db0982618ee72a16"));
            } else if (contains(valtostd, OBFUSCATE("libVivoxNative.so"))) {
                return CreateMonoString(OBFUSCATE("libVivoxNative.so:d6b519d7b4f5f02e5dfdbb3a9a14d2a1"));
                return old_libpath(inst);
            } else {
                return old_libpath(inst);
                    }
            } 


void *hack_thread(void *) {
    
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
	
    // ---------- Hook ---------- //
    setShader("_BumpMap");
	LogShaders();
	Wallhack();
	updateChams();
    
	
	SetPlayerWeapon = (void (*)(void*, int)) getAbsoluteAddress("libil2cpp.so", 0x86FCAC); // 0.18.2
	get_shooting = (bool (*)(void *))getAbsoluteAddress("libil2cpp.so", 0x8FD9A8); 
    SpawnGrenade = (void (*)(void *, int))getAbsoluteAddress("libil2cpp.so", 0xAEC86C); 

	
	MSHookFunction((void *) getAbsoluteAddress(libName, 0xC8A740), (void *) setskins,
                   (void **)&old_setskins); // 0.18.2
    MSHookFunction((void *) getAbsoluteAddress(libName, 0x887894), (void *) gameupdate,
                   (void **)&old_gameupdate); // 0.18.2
        MSHookFunction((void *) getAbsoluteAddress(libName, 0xBF9FA8), (void *) safevalue2,
                   (void **)&safevalue); // 0.19.1
    MSHookFunction((void *) getAbsoluteAddress(libName, 0xBF9FA8), (void *) apkpath,
                   (void **)&old_apkpath); // 0.19.1
    MSHookFunction((void *) getAbsoluteAddress(libName, 0xBF9FA8), (void *) assetspath,
                   (void **)&old_assetspath); // 0.19.1
        MSHookFunction((void *) getAbsoluteAddress(libName, 0xBF9FA8), (void *) libpath,
                   (void **)&old_libpath); // 0.19.1
    MSHookFunction((void *) getAbsoluteAddress(libName, 0xE413AC), (void *) services,
                   (void **)&old_services); // 0.19.1
    
				   
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x8FEDFC), (void *) glov,
                   (void **) &old_glov); // 0.18.2
	MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0xFED8DC), (void *) uidanim, (void **) &old_uidanim);    
	MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0xFED8DC), (void *) uid, (void **) &old_uid);              
	MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x1699140), (void *) No, (void **) &old_No);
    MSHookFunction((void *) getAbsoluteAddress(libName, 0x16B81E4), (void *) SendToTeam,
                   (void **) &old_SendToTeam);
	
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
